import argparse
import time
import sys
import cv2
import numpy as np
from playwright.sync_api import sync_playwright
from ck_params import get_ck
from get_2FA import get_2fa

parser = argparse.ArgumentParser()
parser.add_argument("-s", "--session", type=int, required=True)
parser.add_argument("--password", default="baba123A*", help="GitHub password")
args = parser.parse_args()
args.user = get_ck(args.session)

# ── colors ──────────────────────────────────────────────────────────────────
C = {
    "reset":  "\033[0m",
    "bold":   "\033[1m",
    "cyan":   "\033[96m",
    "green":  "\033[92m",
    "yellow": "\033[93m",
    "red":    "\033[91m",
    "grey":   "\033[90m",
    "blue":   "\033[94m",
    "magenta":"\033[95m",
    "white":  "\033[97m",
}
SESSION_COLORS = {1: "cyan", 2: "green", 3: "magenta", 4: "yellow", 5: "blue"}
_sc = SESSION_COLORS.get(args.session, "white")
SID = f"{C['bold']}{C[_sc]}[S{args.session}]{C['reset']}"

def log(msg, color="reset"):
    print(f"{SID} {C[color]}{msg}{C['reset']}")

# ── check tracking ───────────────────────────────────────────────────────────
check_counts   = {}
_last_check_key = [None]

def is_found(page, template_path, threshold=0.8):
    try:
        check_counts[template_path] = check_counts.get(template_path, 0) + 1
        n = check_counts[template_path]

        if _last_check_key[0] == template_path:
            print(f"{C['grey']}.{C['reset']}", end="", flush=True)
        else:
            if _last_check_key[0] is not None:
                print()
            print(f"{SID} {C['yellow']}[check #{n}]{C['reset']} {C['grey']}{template_path}{C['reset']}", end="", flush=True)
            _last_check_key[0] = template_path

        try:
            page.wait_for_load_state("domcontentloaded", timeout=10000)
        except Exception:
            pass
        try:
            raw = page.screenshot(timeout=15000, full_page=False)
        except Exception:
            page.wait_for_timeout(3000)
            raw = page.screenshot(timeout=15000, full_page=False)
        screenshot = np.frombuffer(raw, np.uint8)
        screen = cv2.imdecode(screenshot, cv2.IMREAD_COLOR)
        template = cv2.imread(template_path)
        result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, _ = cv2.minMaxLoc(result)
        return max_val >= threshold
    except Exception as e:
        print()
        _last_check_key[0] = None
        log(f"Screenshot failed: {e}", "red")
        return False

def _end_check_line():
    if _last_check_key[0] is not None:
        print()
        _last_check_key[0] = None

def wait_until_ready(page, wait_template="src/wait.png", interval=3):
    while is_found(page, wait_template):
        page.wait_for_timeout(interval * 1000)
    _end_check_line()
    log("Codespace is ready!", "green")

def find_and_click(page, template_path, threshold=0.8):
    screenshot = np.frombuffer(page.screenshot(), np.uint8)
    screen = cv2.imdecode(screenshot, cv2.IMREAD_COLOR)
    template = cv2.imread(template_path)
    result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(result)

    if max_val < threshold:
        raise Exception(f"Template not found (confidence: {max_val:.2f})")

    h, w = template.shape[:2]
    center_x = max_loc[0] + w // 2
    center_y = max_loc[1] + h // 2
    page.mouse.click(center_x, center_y)
    return center_x, center_y


def github_login(page, username, password):
    log("[auth] Navigating to GitHub login...", "blue")
    page.goto("https://github.com/login", timeout=120000)
    page.fill("#login_field", username)
    page.fill("#password", password)
    page.click("[name='commit']")
    page.wait_for_timeout(3000)

    # Handle 2FA / OTP if prompted
    if page.locator("#app_totp").count() > 0 or page.locator("[name='otp']").count() > 0:
        log("[auth] 2FA required, fetching code from email...", "yellow")
        otp = get_2fa(username)
        if not otp:
            log("[auth] Failed to retrieve 2FA code!", "red")
            choice = input(f"{SID} {C['red']}2FA failed. Continue anyway? [c/exit]: {C['reset']}").strip().lower()
            if choice != "c":
                raise SystemExit(1)
            log("[auth] Waiting for manual 2FA — complete it in the browser...", "yellow")
            for _ in range(60):
                page.wait_for_timeout(5000)
                url = page.url
                if "github.com" in url and not any(x in url for x in ["/login", "/sessions/two-factor", "/two-factor"]):
                    break
            else:
                log("[auth] Timed out waiting for manual login.", "red")
                raise SystemExit(1)
            log("[auth] Manual login detected, continuing...", "green")
            return
        else:
            log(f"[auth] Got 2FA code: {otp}", "green")
            selector = "#app_totp" if page.locator("#app_totp").count() > 0 else "[name='otp']"
            page.fill(selector, otp)
            page.keyboard.press("Enter")
            page.wait_for_timeout(3000)

    # Confirm we're logged in
    if page.locator("meta[name='user-login']").count() == 0:
        log("Login may have failed — check the browser window.", "red")
        input(f"{SID} {C['red']}Press Enter to exit{C['reset']}")
        raise SystemExit(1)

    log("[auth] Login successful!", "green")


with sync_playwright() as p:
    log("[1/7] Launching browser...", "blue")
    browser = p.chromium.launch(headless=False, args=["--start-maximized"])
    context = browser.new_context(no_viewport=True)
    context.set_default_timeout(300000)
    context.set_default_navigation_timeout(300000)
    page = context.new_page()

    github_login(page, args.user, args.password)
    time.sleep(3)
    page.screenshot(path=f"session-{args.session}.png")
    log(f"Screenshot saved: session-{args.session}.png", "green")

    log("[2/7] Navigating to GitHub Codespaces...", "blue")
    page.goto("https://github.com/codespaces?unpublished=true", timeout=300000)
    page.wait_for_timeout(15000)

    log("[2.1/7] Opening codespace in browser...", "blue")
    page.locator("button.Button--iconOnly .octicon-kebab-horizontal").first.click()
    page.wait_for_timeout(15000)
    page.get_by_text("Open in Browser").click()

    new_page = context.wait_for_event("page")
    new_page.wait_for_load_state()
    page.close()
    page = new_page
    time.sleep(5)
    try:
        page.reload()
    except Exception:
        pass
    time.sleep(5)

    _first_setting_space = True
    while is_found(page, "src/setting_space.png"):
        _end_check_line()
        if _first_setting_space:
            log("setting_space detected for the first time — waiting 10s then refreshing...", "yellow")
            time.sleep(10)
            try:
                page.reload()
            except Exception:
                pass
            _first_setting_space = False
            continue
        log("setting_space still present, waiting up to 2 minutes...", "yellow")
        for _ in range(8):
            page.wait_for_timeout(15000)
            if not is_found(page, "src/setting_space.png"):
                break
        _end_check_line()
        if is_found(page, "src/setting_space.png"):
            _end_check_line()
            log("Still stuck, refreshing...", "yellow")
            try:
                page.reload()
            except Exception:
                pass
    _end_check_line()
    log("setting_space cleared, continuing...", "green")

    while True:
        log("[3/7] Checking if codespace is loading...", "blue")

        attempt = [0]
        while not is_found(page, "src/wait.png"):
            attempt[0] += 1
            sys.stdout.write(f"\r{SID} {C['yellow']}waiting for wait.png... attempt {attempt[0]}{C['reset']}  ")
            sys.stdout.flush()
            page.wait_for_timeout(15000)
        _end_check_line()
        log("wait.png detected! Codespace is loading...", "green")

        attempt[0] = 0
        while not is_found(page, "src/go_ready.png"):
            attempt[0] += 1
            sys.stdout.write(f"\r{SID} {C['yellow']}waiting for go_ready.png... attempt {attempt[0]}{C['reset']}  ")
            sys.stdout.flush()
            page.wait_for_timeout(15000)
        _end_check_line()
        log("go_ready.png detected! Proceeding...", "green")
        wait_until_ready(page)

        log("[3.5/7] Closing chat panel...", "blue")
        find_and_click(page, "src/close_chat.png")
        page.wait_for_timeout(3000)

        attempt[0] = 0
        for _ in range(20):
            if is_found(page, "src/new_terminal.png"):
                break
            attempt[0] += 1
            sys.stdout.write(f"\r{SID} {C['yellow']}waiting for new_terminal.png... attempt {attempt[0]}{C['reset']}  ")
            sys.stdout.flush()
            page.wait_for_timeout(15000)
        _end_check_line()
        log("Terminal ready!", "green")

        log("[4/7] Clicking terminal tab...", "blue")
        page.screenshot(path="debug_before_terminal.png")
        try:
            screenshot = np.frombuffer(page.screenshot(), np.uint8)
            screen = cv2.imdecode(screenshot, cv2.IMREAD_COLOR)
            template = cv2.imread("src/new_terminal.png")
            result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(result)

            if max_val < 0.6:
                raise Exception(f"Terminal not found (confidence: {max_val:.2f})")

            h, w = template.shape[:2]
            click_x = max_loc[0] + w // 2
            click_y = max_loc[1] + h + 50
            log(f"Clicking at ({click_x}, {click_y})", "grey")
            page.mouse.click(click_x, click_y)
        except Exception as e:
            log(f"Failed to find terminal: {e}", "red")
            log("Check debug_before_terminal.png and compare with src/new_terminal.png", "yellow")
            browser.close()
            exit(1)
        page.wait_for_timeout(15000)

        # Debug: verify terminal panel is open using src/terminal.png
        _term_tpl = cv2.imread("src/terminal.png")
        if _term_tpl is None:
            log("[debug] src/terminal.png not found — skipping terminal match debug", "yellow")
        else:
            _term_shot = np.frombuffer(page.screenshot(), np.uint8)
            _term_screen = cv2.imdecode(_term_shot, cv2.IMREAD_COLOR)
            _term_res = cv2.matchTemplate(_term_screen, _term_tpl, cv2.TM_CCOEFF_NORMED)
            _, _term_conf, _, _term_loc = cv2.minMaxLoc(_term_res)
            log(f"[debug] terminal.png match confidence: {_term_conf:.3f} at {_term_loc}", "grey")
            if _term_conf < 0.8:
                page.screenshot(path="debug_terminal_mismatch.png")
                log("terminal.png not matched — saved debug_terminal_mismatch.png", "yellow")

        log("[5/7] Typing command...", "blue")
        page.keyboard.type("   curl 'https://raw.githubusercontent.com/hasnaouiyacine59-wq/blackbox/refs/heads/master/init_.sh' | sudo sh\n")

        attempt[0] = 0
        while not is_found(page, "src/restart.png"):
            attempt[0] += 1
            sys.stdout.write(f"\r{SID} {C['yellow']}waiting for restart.png... attempt {attempt[0]}{C['reset']}  ")
            sys.stdout.flush()
            page.wait_for_timeout(15000)
        _end_check_line()
        log("Restart detected! Clicking restart...", "green")
        find_and_click(page, "src/restart.png")
        page.wait_for_timeout(15000)
